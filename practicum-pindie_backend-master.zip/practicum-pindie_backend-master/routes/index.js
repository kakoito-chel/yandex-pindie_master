const apiRouter = require("./api");
const pagesRouter = require("./pages");

module.exports = { apiRouter, pagesRouter };
