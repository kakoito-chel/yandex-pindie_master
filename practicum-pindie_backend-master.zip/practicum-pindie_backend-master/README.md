# PindieAPI

### — [Фронтенд](https://github.com/lumenpearson/practicum-pindie_frontend)

### — [Домен фронтенда](https://lumens-pindie.nomoredomainswork.ru)

### — IP-адрес: `158.160.165.240`
